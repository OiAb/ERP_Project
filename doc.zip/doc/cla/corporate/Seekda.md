Austria, 2016-06-16

Seekda GmbH agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Holger Lausen holger.lausen@seekda.com https://github.com/holgerlausen

List of contributors:

Holger Lausen holger.lausen@seekda.com https://github.com/holgerlausen
Florian Kisser florian.kisser@seekda.com https://github.com/floriankisser


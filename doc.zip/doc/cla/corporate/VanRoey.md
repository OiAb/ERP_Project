Belgium 2016-04-11

Van Roey agrees to the terms of the Odoo Corporate
Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Yenthe Van Ginneken  yenthe.vanginneken@vanroey.be https://github.com/Yenthe666

List of contributors:

Yenthe Van Ginneken  yenthe.vanginneken@vanroey.be https://github.com/Yenthe666 (up to 2018-01-26)
Vincent Adriaensen vincent.adriaensen@vanroey.be https://github.com/vincentadriaensen
Pol Van Dingenen pol.vandingenen@vanroey.be https://github.com/Cyhexy
Ward Marissen Ward.Marissen@vanroey.be https://github.com/Wardm95

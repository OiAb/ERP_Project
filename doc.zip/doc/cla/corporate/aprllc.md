United States, 11/03/2016

APR, LLC agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Joseph McDonald jmcdonald@goapr.com https://github.com/joe1981alAPR

List of contributors:

Joseph McDonald jmcdonald@goapr.com https://github.com/joe1981alAPR

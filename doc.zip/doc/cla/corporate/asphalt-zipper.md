USA, 2015-04-22

Asphalt Zipper agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Matt Taylor matt454357@gmail.com https://github.com/matt454357

List of contributors:

Matt Taylor matt454357@gmail.com https://github.com/matt454357
Scott Saunders scosist@asphaltzipper.com https://github.com/scosist

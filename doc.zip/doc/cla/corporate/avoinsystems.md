Finland, 2015-06-07

Web-veistämö Oy (auxiliary business name Avoin.Systems) agrees to the terms of the Odoo Corporate
Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Erno Iipponen erno.iipponen@avoin.systems https://github.com/iipponen

List of contributors:

Miku Laitinen miku.laitinen@avoin.systems https://github.com/mlaitinen
Svante Suominen svante.suominen@avoin.systems https://github.com/svantesuominen
Erno Iipponen erno.iipponen@avoin.systems https://github.com/iipponen
Tuomo Aura tuomo.aura@avoin.systems https://github.com/tuomoaura
Atte Isopuro atte.isopuro@avoin.systems https://github.com/aisopuro
Mikko Närjänen mikko.narjanen@avoin.systems https://github.com/mtnarjan
Toni Pesola toni.pesola@avoin.systems https://github.com/tonipes
Santeri Valjakka santeri.valjakka@avoin.systems https://github.com/hegenator

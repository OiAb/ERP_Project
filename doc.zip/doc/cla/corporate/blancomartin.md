Chile, 2019-07-12

Blanco Martín & Asociados agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Daniel Blanco daniel@blancomartin.cl https://github.com/danisan

Corporation name: Blanco Martin & Asociados EIRL
Corporation address: Av. Apoquindo 6410
                     Of. 212 Las Condes, (RM)
Country: Chile
Point of contact: Daniel Blanco
Title: Director - Representante Legal
Email: daniel@blancomartin.cl
Telephone: +56 2 28400990

List of contributors:

* Fernando de La Barrera fernando@blancomartin.cl https://github.com/bmya-fed
* Alejandro Paciotti alejandro@blancomartin.cl https://github.com/alp-bmya
* Albert Nieriz albert@blancomartin.cl https://github.com/aln-bmya
* Bruno Figares bruno@blancomartin.cl https://github.com/brf-bmya
* Susana Vazquez susana@blancomartin.cl https://github.com/suv-bmya

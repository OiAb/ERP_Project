Lithuania, 2017-01-26

Boolit JSC agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Andrius Laukavičius dev@boolit.eu https://github.com/oerp-odoo

List of contributors:

Dainius Kaniava dka@boolit.eu https://github.com/boolit-dka
Andrius Laukavičius dev@boolit.eu https://github.com/oerp-odoo

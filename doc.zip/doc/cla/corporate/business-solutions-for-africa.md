The Democratic Republic of Congo, April 3rd 2019

Business Solutions For Africa agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Vincent Luba vincent@biz-4-africa.com https://github.com/BIZ4Africa

List of contributors:

Vincent Luba vincent@biz-4-africa.com https://github.com/BIZ4Africa

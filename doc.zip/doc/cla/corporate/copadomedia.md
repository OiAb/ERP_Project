Germany 2015-02-11

copado MEDIA UG agrees to the terms of the Odoo Corporate 
Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this 
declaration.

Signed,

Mathias Neef mn@copado.de https://github.com/copado

List of contributors:

Mathias Neef mn@copado.de https://github.com/copmn
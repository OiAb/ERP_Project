Canada, August 27th, 2018

D2GO SOLUTIONS INC agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Louis-Philippe Papillon lppapillon@attrix.ca https://github.com/stechnique

List of contributors:

Louis-Philippe Papillon lppapillon@attrix.ca https://github.com/stechnique

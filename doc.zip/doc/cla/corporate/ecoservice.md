Germany, 2019-05-14

ecoservice GbR agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Falk Neubert neubert@ecoservice.de https://github.com/FNeu75

List of contributors:

* Christian Engelhardt c.engelhardt@ecoservice.de https://github.com/c-engelhardt-ecoservice
* Christian Schöttke c.schoettke@ecoservice.de https://github.com/cschoettke
* Falk Neubert neubert@ecoservice.de https://github.com/FNeu75
* Gülhan Celik g.celik@ecoservice.de https://github.com/guelhancelik
* Jan Brodersen 4rmitxes@gmail.com https://github.com/Armitxes
* Kamal Prajapati k.prajapati@ecoservice.de https://github.com/kamalprajapati
* Marcel Much m.much@ecoservice.de https://github.com/mmuch

Belgium, 2016-02-19

EEZEE-IT agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Antony Brugger antony.brugger@eezee-it.com https://github.com/antonybrugger

List of contributors:

Aristóbulo Meneses aristobulo.meneses@eezee-it.com https://github.com/aristobulo-eezee
Janik De Goÿ janik.de.goy@eezee-it.com https://github.com/jdegoy
François Lawarrée francois.lawarre@eezee-it.com https://github.com/francoislawarree
José Moreno jose.moreno@eezee-it.com https://github.com/jose-eezee
Javier Carrasco javier.carrasco@eezee-it.com https://github.com/jose-eezee
David Cajot david.cajot@eezee-it.com https://github.com/dcajot
François Honoré francois.honore@eezee-it.com https://github.com/eezeefho
Bénédicte Hanet benedicte.hanet@eezee-it.com https://github.com/bene1505
Analisa Carbone analisa.carbone@eezee-it.com https://github.com/analisaodoo
Nicolas De Moreau nicolas.demoreau@eezee-it.com https://github.com/ndemoreau
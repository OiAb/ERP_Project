China, 2015-12-10

Elico Corporation agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Eric Caudal eric.caudal@elico-corp.com https://github.com/elicoidal

List of contributors:
Eric Caudal eric.caudal@elico-corp.com https://github.com/elicoidal
Sébastien Maillard sebastien.maillard@elico-corp.com https://github.com/seb-elico
Siyuan Gu siyuancn@hotmail.com https://github.com/siyuancn
Wang Liping lynn.config@gmail.com https://github.com/lynndotconfig
Luke Zheng cialuo@126.com https://github.com/cialuo
Gary Wei gary.wei@elico-corp.com https://github.com/Garywei1314
Yaxi Zheng zheng.yaxi@elico-corp.com https://github.com/Elico-Yaxi
Faust Huang faust_huang@hotmail.com https://github.com/fausthuang
Yu Lin yu_lin@me.com https://github.com/uynil
Xie Xiaopeng hellomyjob@163.com https://github.com/xie8899
Connie Xiao connie.xiao@elico-corp.com https://github.com/ConnieXiao
Alex Duan alex.duan@elico-corp.com https://github.com/duanyp1991
Liu Lixia liulixia19901988@163.com https://github.com/liulixia1990
Liliane Li liliane.li@elico-corp.com http://github.com/lilianeandbrody
Rona Lin ssauapw@qq.com https://github.com/Rona111
Bob Luo luo.yumeng0831@gmail.com https://github.com/m6519578
Waller Zhang waller.zhang@elico-corp.com https://github.com/wallerzhang

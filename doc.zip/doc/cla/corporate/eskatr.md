Turkey, 2015-03-27

Eska Yazılım ve Danışmanlık A.Ş. agrees to the terms of the Odoo Corporate
Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Levent Karakaş leventk@eskayazilim.com.tr https://github.com/eskatr

List of contributors:

Levent Karakaş leventk@eskayazilim.com.tr https://github.com/levkar

USA, 2015-02-17

EUGE Consulting agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

E.R. Spada II er@eugeconsulting.com https://github.com/spadae22

List of contributors:

E.R. Spada II er@eugeconsulting.com https://github.com/spadae22
E.R. Spada III support@eugeconsulting.com https://github.com/spadae22

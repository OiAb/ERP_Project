Belgium, 2017-05-03

fks agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Eric Smets eric.smets@fks.be https://github.com/ikzent

List of contributors:

Eric Smets eric.smets@fks.be https://github.com/ikzent
Frank Gevaerts frank.gevaerts@fks.be https://github.com/gevaerts
Tilda Jacobs tilda.jacobs@fks.be
Gert Claesen gert.claesen@fks.be


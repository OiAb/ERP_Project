Spain, 2019-12-11

ForgeFlow S.L. agrees to the terms of the
Odoo  Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Jordi Ballester jordi.ballester@forgeflow.com https://github.com/JordiBForgeFlow

List of contributors:

Aarón Henríquez ahenriquez@forgeflow.com https://github.com/AaronHForgeFlow
Lois Rilo lois.rilo@forgeflow.com https://github.com/LoisRForgeFlow
Miquel Raich miquel.raich@forgeflow.com https://github.com/MiquelRForgeFlow
Jordi Ballester jordi.ballester@forgeflow.com https://github.com/JordiBForgeFlow
Hector Villarreal hector.villarreal@forgeflow.com https://github.com/HviorForgeFlow

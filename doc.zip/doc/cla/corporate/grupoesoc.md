Spain, 2015-05-07

Grupo ESOC agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Nuria Pastor <n.pastor@grupoesoc.es> https://github.com/grupoesoc/

List of contributors:

Jairo Llopis <j.llopis@grupoesoc.es> https://github.com/Yajo (up to 2016-05-01)

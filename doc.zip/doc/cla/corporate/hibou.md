USA, 2015-10-20

Hibou Corp. agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Jared Kipe jared@hibou.io https://github.com/jaredkipe

List of contributors:

Jared Kipe jared@hibou.io https://github.com/jaredkipe

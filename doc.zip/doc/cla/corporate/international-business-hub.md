Switzerland, 2018-07-31

International Business Hub agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Sandro Pignataro pignatarosandro@gmail.com https://github.com/Pigna74

List of contributors:

Guido Notari guido.notari@gmail.com https://github.com/gnotari
Matteo Bilotta byloth@gmail.com https://github.com/Byloth


France, 2015-04-18

Iris-solutions agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Alexandre Laidin alexandre.laidin@iris-solutions.fr https://github.com/iris-solutions

List of contributors:

Alexandre Laidin alexandre.laidin@iris-solutions.fr https://github.com/alaidin

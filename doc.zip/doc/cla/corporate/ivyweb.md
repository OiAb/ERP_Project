South Africa, 2019/05/28

IvyWeb agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Carel van Dam carelvdam@gmail.com https://github.com/Carelvd

List of contributors:

Carel van Dam carelvdam@gmail.com https://github.com/Carelvd
Carel van Dam carel@ivyweb.co.za https://github.com/carelvd
Jacobus Erasmus jacobus@ivyweb.co.za https://github.com/jacobuserasmus
Waldo Smith waldo@ivyweb.co.za https://github.com/smokie22

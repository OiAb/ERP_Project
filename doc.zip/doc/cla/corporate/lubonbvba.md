Belgium, 18/7/2015

Lubon bvba agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Luc Bonjean luc@lubon.bvba https://github.com/lubonbvba

List of contributors:

Luc Bonjean luc@lubon.be https://github.com/lubonbvba

France, 2015-03-20

Makina Corpus agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Mathieu Le Marec - Pasquet, mpa@makina-corpus.com, https://github.com/kiorky

List of contributors:

Mathieu Le Marec - Pasquet, mpa@makina-corpus.com, https://github.com/kiorky
Makina Corpus, sysadmin@makina-corpus.com, http://www.makina-corpus.com

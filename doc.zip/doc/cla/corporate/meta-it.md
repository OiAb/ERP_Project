France, 2015 June 25

META-IT agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Robin Lucbenet robin@meta-it.fr https://github.com/n1b0r

List of contributors:

Guillaume Masson guillaume.masson@meta-it.fr https://github.com/metaminux

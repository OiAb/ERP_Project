Belgium, 2017-11-14

METRUM SA agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Jonathan Nemry jonathan.nemry@metrum.lu https://github.com/JonathanNEMRY

List of contributors:

Pascal Pelzer pascal.pelzer@metrum.lu https://github.com/PascalPelzer
Jonathan Nemry jonathan.nemry@metrum.lu https://github.com/JonathanNEMRY

Serbia, 2018-06-11

Modoolar agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Petar Najman petar.najman@modoolar.com https://github.com/pnajman-modoolar

List of contributors:

- Aleksandar Gajić aleksandar.gajic@modoolar.com https://github.com/agajic-modoolar
- Igor Jovanović igor.jovanovic@modoolar.com https://github.com/ijovanovic-modoolar
- Mladen Meseldžija mladen.meseldzija@modoolar.com https://github.com/mmeseldzija-modoolar
- Petar Najman petar.najman@modoolar.com https://github.com/pnajman-modoolar
- Slađan Kantar sladjan.kantar@modoolar.com https://github.com/skantar

Belgium, 2015-06-23

Noviat agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Luc De Meyer luc.demeyer@noviat.com https://github.com/noviat

List of contributors:

Luc De Meyer luc.demeyer@noviat.com https://github.com/luc-demeyer
Thomas Fossoul thomas.fossoul@noviat.com https://github.com/fossoult
Francois Legros francois.legros@noviat.com https://github.com/francoislegros
Aissam Musnaoui aissam.musnaoui@noviat.com https://github.com/saisami
Eric Christensen eric.christensen@noviat.com https://github.com/eric-christensen-noviat

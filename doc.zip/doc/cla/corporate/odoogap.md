PromptEQUATION, 2017-09-03

PromptEquation/ OdooGap agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Diogo Duarte dduarte@odoogap.com https://github.com/dduarte-odoogap

List of contributors:

Diogo Duarte dduarte@odoogap.com https://github.com/dduarte-odoogap
Diogo Duarte diogocarvalhoduarte@gmail.com https://github.com/dduarte-odoogap
Carlos Fonseca cfonseca@odoogap.com https://github.com/cfonseca-odoogap
Carlos Fonseca carlosmigueldafonseca@gmail.com https://github.com/cpintofonseca

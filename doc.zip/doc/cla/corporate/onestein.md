Netherlands, 2016-02-18

Onestein BV agrees to the terms of the Odoo Corporate 
Contributor License Agreement v1.0.

We declare that we are authorized and able to make this agreement and sign
this declaration.

Signed,

*  Samer Nefawa <s.nefawa@onestein.nl> https://github.com/samernefawa

List of contributors:

*  Samer Nefawa <s.nefawa@onestein.nl> https://github.com/samernefawa
*  Niels Middeldorp <n.middeldorp@onestein.nl> https://github.com/nielsmiddeldorp
*  Kevin Graveman <k.graveman@onestein.nl> https://github.com/pankk
*  Dennis Sluijk <d.sluijk@onestein.nl> https://github.com/tarteo
*  Richard Dijkstra <r.dijkstra@onestein.nl> https://github.com/RichDijk
*  Andrea Stirpe <a.stirpe@onestein.nl> https://github.com/astirpe

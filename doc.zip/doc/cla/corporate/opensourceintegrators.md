The United States of America, 2018-12-04

Open Source Integrators agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Greg Mader gmader@opensourceintegrators.com https://github.com/gmader

List of contributors:

Greg Mader gmader@opensourceintegrators.com https://github.com/gmader
Antonio Yamuta ayamuta@opensourceintegrators.com https://github.com/agyamuta
Balaji Kannan bkannan@opensourceintegrators.com https://github.com/b-kannan
Bhavesh Odedra bodedra@opensourceintegrators.com https://github.com/bodedra
Daniel Reis dreis@opensourceintegrators.com https://github.com/dreispt
Mayank Gosai mgosai@opensourceintegrators.com https://github.com/mgosai
Maxime Chambreuil mchambreuil@opensourceintegrators.com https://github.com/max3903
Michael Allen mallen@opensourceintegrators.com https://github.com/osimallen
Sandeep Magukiya smangukiya@opensourceintegrators.com https://github.com/smangukiya
Steven Campbell scampbell@opensourceintegrators.com https://github.com/osi-scampbell
Sudarshan Kadalazhi skadalazhi@opensourceintegrators.com https://github.com/sudarshan1607
Wolfgang Hall shall@opensourceintegrators.com https://github.com/wolfhall

United Kingdom, 2015-05-22

OpusVL agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Nuria Arranz-Velazquez nuria@opusvl.com https://github.com/nuria-opusvl

List of contributors:

JJ Allen jj@opusvl.com https://github.com/jj-opusvl
Colin Newell colin.newell@opusvl.com https://github.com/colinnewell
Peter Alabaster peter.alabaster@opusvl.com https://github.com/petera-opusvl
Nuria Arranz-Velazquez nuria@opusvl.com https://github.com/nuria-opusvl
Stuart J Mackintosh sjm@opusvl.com https://github.com/StuartJMackintosh
Edward Bagulay edward.bagulay@opusvl.com https://github.com/edwardbagulay
Nick Booker nick.booker@opusvl.com https://github.com/Nick-OpusVL
Barnie Giltrap barnie.giltrap@opusvl.com https://github.com/bjgiltrap

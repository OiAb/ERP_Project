USA, 08/13/2016

Pine View Buildings agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Freeman Helmuth freeman@pineview.biz https://github.com/busyfritz

List of contributors:

Freeman Helmuth freeman@pineview.biz https://github.com/busyfritz

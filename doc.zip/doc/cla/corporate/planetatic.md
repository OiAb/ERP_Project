Spain, 2019-01-07

Penedestic Solucions, SLP agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Francisco Fernández ffernandez@planetatic.com https://github.com/FFernandez-PlanetaTIC

List of contributors:

Àngel Manonelles amanonelles@planetatic.com https://github.com/AManonelles-PlanetaTIC
Francisco Fernández ffernandez@planetatic.com https://github.com/FFernandez-PlanetaTIC
Josep Maria Pinyol Ferret jmpinyol@planetatic.com https://github.com/JMPinyol-PlanetaTIC
Lluís Rovira Olivé lrovira@planetatic.com https://github.com/LRovira-PlanetaTIC
Marc Poch mpoch@planetatic.com https://github.com/MPoch-PlanetaTIC

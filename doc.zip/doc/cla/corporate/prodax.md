Bulgaria, 2015-06-09

Prodax Ltd. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Donka Lapunova donka64@mail.bg https://github.com/OdooBulgaria

List of contributors:

Donka Lapunova donka64@mail.bg https://github.com/donchetoo

Vassil Toumbev vassy@mail.bg https://github.com/vassy

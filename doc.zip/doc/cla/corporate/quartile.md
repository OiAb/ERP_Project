Hong Kong, 2017-09-18

Quartile Limited agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Yoshi Tashiro tashiro@quartile.co https://github.com/yostashiro

List of contributors:

Yoshi Tashiro tashiro@quartile.co https://github.com/yostashiro
Tim Lai tl@quartile.co https://github.com/TimLai125
Tomoko Matsumura nako@quartile.co https://github.com/nakometal

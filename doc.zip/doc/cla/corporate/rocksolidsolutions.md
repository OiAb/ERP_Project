United States, 2016-05-25

Rock Solid Solutions, LLC <http://www.rocksolidsolutions.org> agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Daniel Kauffman, Manager rocksolidsolutions@users.noreply.github.com <https://github.com/rocksolidsolutions>

List of contributors:

Daniel Kauffman rocksolidsolutions@users.noreply.github.com <https://github.com/rocksolidsolutions>

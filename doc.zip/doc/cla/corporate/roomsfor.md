Hong Kong, 2015-04-27

Rooms For (Hong Kong) Limited agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Yoshi Tashiro tashiro@roomsfor.hk https://github.com/yostashiro

List of contributors:

Yoshi Tashiro tashiro@roomsfor.hk https://github.com/yostashiro
Manami Hashi manami@roomsfor.hk https://github.com/manamirfhk

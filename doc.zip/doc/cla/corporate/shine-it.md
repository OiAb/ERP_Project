China, 2018-04-28

Shine IT agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Tony Gu tony@openerp.cn https://github.com/digitalsatori

List of contributors:
Tony Gu tony@openerp.cn https://github.com/digitalsatori
Joshua Jan joshua@openerp.cn https://github.com/joshuajan
Xiao Guo  xerxes@openerp.cn https://github.com/xerxesnoPT


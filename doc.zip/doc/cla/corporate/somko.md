Belgium, 30/01/2017

Somko agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Frederik Santens info@somko.be https://github.com/somko

List of contributors:

Frederik Santens info@somko.be https://github.com/somko
Thomas Vanmellaerts thomas.vanmellaerts@somko.be https://github.com/thomassomko
Kasper Declercq kasper.declercq@somko.be https://github.com/kasperdeclercq
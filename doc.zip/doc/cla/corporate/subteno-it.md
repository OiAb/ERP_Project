France, 2018-11-14

Subteno IT agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Sébastien LANGE sebastien.lange@subteno-it.fr https://github.com/sla-subteno-it

List of contributors:

Christian LECOUFLE christian.lecoufle@subteno-it.fr https://github.com/cle-subteno-it
Vincent COFFIN vincent.coffin@subteno-it.fr https://github.com/vco-subteno-it

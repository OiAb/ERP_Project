France, 2015-04-14

TecLib agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Laurent Destailleur ldestailleur@teclib.com https://github.com/eldy

List of contributors:

Laurent Destailleur ldestailleur@teclib.com https://github.com/eldy
David Halgand dhalgand@teclib.com https://github.com/halgandd
Guillaume Masson gmasson@teclib.com https://github.com/metaminux

Spain, 2017-10-14

Trey, Kilobytes de Soluciones S.L. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Roberto Lizana robertolizana@trey.es https://github.com/rlizana

List of contributors:

Abraham Gonzalez abraham@trey.es https://github.com/AbrahamTrey
Azucena Luque azucena@trey.es https://github.com/azucenatrey
Jorge Camacho jorgecamacho@trey.es https://github.com/jctrey
Roberto Lizana robertolizana@trey.es https://github.com/rlizana
Rosa Sánchez rosa@trey.es https://github.com/RSanchezAbad

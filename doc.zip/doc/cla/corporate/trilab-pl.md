Poland, 10.06.2019

Trilab Sp. z o.o. Sp. K. agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Janusz Harkot jh@trilab.pl https://github.com/jerzyk

List of contributors:

Krystian Harkot kharkot@trilab.pl https://github.com/kharkot
Janusz Harkot jh@trilab.pl https://github.com/jerzyk


México, 2015-02-09

Vauxoo agrees to the terms of the Odoo Corporate Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Moisés López moylop260@vauxoo.com https://github.com/moylop260

List of contributors:

Humberto Arocha hbto@vauxoo.com https://github.com/hbto
Javier Duran javier@vauxoo.com
Moisés López moylop260@vauxoo.com https://github.com/moylop260
Nhomar Hernández nhomar@vauxoo.com https://github.com/nhomar
Sabrina Romero sabrina@vauxoo.com https://github.com/dsabrinarg
Yanina Aular yanina.aular@vauxoo.com https://github.com/yaniaular
Oscar Alcala oszckar@gmail.com.com https://github.com/oscarolar
Oscar Alcala oscar@vauxoo.com https://github.com/oscarolar
Luis Ernesto García Medina ernesto_gm@vauxoo.com https://github.com/ernesto-gm
Julio Serna julio@vauxoo.com https://github.com/JulioSerna
Jorge Angel Naranjo Rogel jorge_nr@vauxoo.com https://github.com/jorgenaranjo
Jose Antonio Morales Ponce jose@vauxoo.com https://github.com/josemoralesp
Tulio Ruiz tulio@vauxoo.com https://github.com/ruiztulio
Luis Torres luis_t@vauxoo.com https://github.com/luistorresm
Gabriela Quilarque gabriela@vauxoo.com https://github.com/gquilarque
Katherine Zaoral kathy@vauxoo.com https://github.com/zaoral
Hugo Adan hugo@vauxoo.com https://github.com/hugho-ad
Alan Guzman aguzman@vauxoo.com https://github.com/alan-guzman
Leonardo Astros leonardo@vauxoo.com https://github.com/Codemaker83
Jose Angel Fentanez Delfin joseangel@vauxoo.com https://github.com/Angelfentanez
Osval Reyes osval@vauxoo.com https://github.com/osvalr
Jose Suniaga josemiguel@vauxoo.com https://github.com/suniagajose
Luis González lgonzalez@vauxoo.com https://github.com/luisg123v
Oriana Maita oriana@vauxoo.com https://github.com/maitaoriana
Gabriela Mogollon gmogollon@vauxoo.com https://github.com/GavyMG
Jesus Zapata jesus@vauxoo.com https://github.com/JesusZapata
Germana Oliveira germana@vauxoo.com https://github.com/goliveirab
Mariano Fernandez mariano@vauxoo.com https://github.com/Batuto
Edgar Rivero edgar@vauxoo.com https://github.com/egrivero
Edilianny Sánchez esanchez@vauxoo.com https://github.com/edy1192
Alexander Olivares alexander@vauxoo.com https://github.com/alxolivares
Jose Manuel Robles josemanuel@vauxoo.com https://github.com/keylor2906
Erick Birbe erick@vauxoo.com https://github.com/ebirbe
Tomas Alvarez tomas@vauxoo.com https://github.com/tomeyro
Carmen Liliana Miranda González carmen@vauxoo.com https://github.com/CarmenMiranda
Arturo Flores arturo@vauxoo.com https://github.com/umiphos
Deivis Laya deivis@vauxoo.com https://github.com/deivislaya
Yennifer Santiago yennifer@vauxoo.com https://github.com/ysantiago

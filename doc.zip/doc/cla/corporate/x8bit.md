México, 2016-07-19

X8BIT agrees to the terms of the Odoo Corporate Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Juan Carlos del Valle juan@x8bit.com https://github.com/imekinox

List of contributors:

Juan Carlos del Valle juan@x8bit.com https://github.com/imekinox
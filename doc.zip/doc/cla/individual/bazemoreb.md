USA, 2017-10-01

I hereby agree to the terms of the Odoo Individual Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Brandon Bazemore brandonb@audian.com  https://github.com/bazemoreb

South Africa, 05/02/2019

I hereby agree to the terms of the Odoo Individual Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Carel van Dam carelvdam@gmail.com https://github.com/carelvd

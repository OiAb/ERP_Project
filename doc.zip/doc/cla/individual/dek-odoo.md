India, 2018-08-26

I hereby agree to the terms of the Odoo Individual Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Devendra kavthekar dkatodoo@gmail.com https://github.com/dek-odoo

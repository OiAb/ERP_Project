Ecuador, 14th of March, 2016

I hereby agree to the terms of the Odoo Individual Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Javier Casas javcasas@gmail.com https://github.com/javcasas

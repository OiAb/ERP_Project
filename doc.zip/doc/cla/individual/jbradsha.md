United Kingdom, 2015-05-22

I hereby agree to the terms of the Odoo Individual Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

John Bradshaw - jbradsha@github.com - https://github.com/jbradsha

India, 2018-07-31

I hereby agree to the terms of the Odoo Individual Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Jothimani Rajagopal jothimani1991@gmail.com https://github.com/jothimani-r

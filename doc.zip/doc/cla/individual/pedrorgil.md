Spain, 2015-09-04

I hereby agree to the terms of the Odoo Individual Contributor License Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this declaration.

Signed,

Pedro Rodriguez Gil pedro@otherway.es https://github.com/pedrorgil


Spain, 2017-10-24

I hereby agree to the terms of the Odoo Individual Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Silvio Fernandez silviofernandezmarin@gmail.com https://github.com/silviofdez
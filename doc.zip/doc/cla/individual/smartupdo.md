Dominican Republic, October 26, 2016

I hereby agree to the terms of the Odoo Individual Contributor License
Agreement v1.0.

I declare that I am authorized and able to make this agreement and sign this
declaration.

Signed,

Richard Aquino richard@smartup.do https://github.com/smartupdo

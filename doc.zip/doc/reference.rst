:types: reference

=========
Reference
=========

.. toctree::
    :titlesonly:

    reference/orm
    reference/data
    reference/actions
    reference/views
    reference/module
    reference/cmdline
    reference/security
    reference/testing

    reference/http
    reference/qweb
    reference/javascript_cheatsheet
    reference/javascript_reference
    reference/translations
    reference/reports
    reference/mixins
    reference/guidelines
    reference/mobile

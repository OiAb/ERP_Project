:banner: banners/web_service_api.jpg
:types: api

============
Web Services
============

.. toctree::
    :titlesonly:

    webservices/odoo
    webservices/iap
    webservices/upgrade
    webservices/localization
